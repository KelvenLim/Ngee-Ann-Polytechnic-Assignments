/**-----------------------------------------------**/
/**       Lim Wee Liang Kelven, S10221788K        **/
/**             Credit Card Application           **/
/**-----------------------------------------------**/


use CreditCardSys 
go

/**====== Create procedure for creating new credit card ======**/ 
if exists (select * from sys.objects where type = 'P' and name = 'uspCreateCreditCard') drop proc uspCreateCreditCard
go

create or alter proc uspCreateCreditCard (@custid char(7)) as
begin

	-- Declare vairables
	declare @ccno char(16), @cvv char(3), @validthru char(7), @creditlimit smallmoney, @currentbal smallmoney, @status varchar(10)

	-- Set CCNo by random
	set @ccno = cast((select floor(rand() * 9999999999999999)) as numeric)

	-- Check if CCNo already exists. if yes, generate a new one
	while exists(select * from CreditCard where CCNo = @ccno)
		set @ccno = cast((select floor(rand() * 9999999999999999)) as numeric)
		
	-- Set CVV by random
	set @cvv = (select floor(rand() * 999))

	-- Check if CVV already exists. if yes, generate a new one
	while exists(select * from CreditCard where CCCVV = @cvv)
		set @cvv = (select floor(rand() * 999))

	-- Set ValidThru date
	 set @validthru = format(dateadd(year, 5, getdate()), 'MM/yyyy') -- Expires after 5 years

	-- Set CreditLimit
	set @creditlimit = (select CustAnnualIncome from Customer where CustId = @custid) / 2

	-- Set CurrentBal
	set @currentbal = @creditlimit

	-- Set Status
	set @status = 'Active'

	-- Checks for unknown error
	if @@ERROR <> 0
		return -104 --'Unknown error occured. Please try again.'

	-- If no error, insert new row into CreditCard table
	insert into CreditCard(CCNo, CCCVV, CCValidThru, CCCreditLimit, CCCurrentBal, CCStatus, CCCustId) 
	values (@ccno, @cvv, @validthru, @creditlimit, @currentbal, @status, @custid)

	return
end
go


/**====== Create trigger after insert on CreditCard table ======**/ 
if exists (select * from sys.objects where type = 'TR' and name = 'trigCreditCardAdded') drop trigger trigCreditCardAdded
go

create or alter trigger trigCreditCardAdded on CreditCard after insert as
print 'New credit card information added'
return
go


/**====== Create procedure for credit card application process ======**/ 
if exists (select * from sys.objects where type = 'P' and name = 'uspCreditCardApplication') drop proc uspCreditCardApplication
go

create or alter proc uspCreditCardApplication (@nric char(9), @name varchar(50), @dob smalldatetime, @address varchar(100), @contact varchar(15), 
												@email varchar(50), @annualincome smallmoney) 
as
begin
	-- Declare variables
	declare @lastid char(7), @newid varchar(7), @joindate smalldatetime, @age smalldatetime

	-- Create new CustID
	set @lastid = (select top 1 CustId from Customer order by CustId desc)	-- Finds last id
	set @newid = SUBSTRING(@lastid, 2, 7) + 1								-- Splits 'C' from numeric portion and adds 1
	set @newid = ('C' + RIGHT('000000' + CONVERT(VARCHAR(6), @newid), 6))	-- Concatenate 'C' with new numeric portion

	-- Create CustJoinDate and age
	set @joindate = (select getdate())
	set @age = datediff(year, @dob, @joindate)

	-- Checks if customer is below 21
	if (@age < 21)
		return -101 --'Customer must be 21 years old and above to apply for a credit card'

	-- Checks if customer is above 70
	if (@age > 70)
		return -102 --'Customer must be 70 years old and below to apply for a credit card'

	-- Checks if customer has a minimum of $30k annual income
	if (@annualincome < 30000)
		return -103 --'Customer must have a minimal gross annual income of S$30k to apply for a credit card'

	-- Checks for unknown error
	if @@ERROR <> 0
		return -104 --'Unknown error occured. Please try again.'

	-- If no error, insert new row into Customer table
	insert into Customer(CustID, CustNRIC, CustName, CustDOB, CustAddress, CustContact, CustEmail, CustAnnualIncome, CustJoinDate, CustStatus)
	values (@newid, @nric, @name, @dob, @address, @contact, @email, @annualincome, @joindate, 'Active')

	-- Create a new CreditCard account
	exec uspCreateCreditCard @newid
	return
end
go


/**====== Create trigger after insert on Customer table ======**/ 
if exists (select * from sys.objects where type = 'TR' and name = 'trigApplicationSuccessful') drop trigger trigApplicationSuccessful
go

create or alter trigger trigApplicationSuccessful on Customer after insert as
print 'Application was successful'
return
go

/**====== Create procedure to see rewards under a customer ======**/ 
if exists (select * from sys.objects where type = 'P' and name = 'uspCustomerReward') drop proc uspCustomerReward
go

create or alter proc uspCustomerReward (@ccno varchar(50) = null) as
begin
	-- if credit card number is not provided, select all customers and rewards
	if (@ccno is null)
		select c.CustId, c.CustName, r.RewDesc, r.RewAmount, r.RewValidTill, r.RewStatus
		from CreditCard as cc 
		inner join Customer as c on c.CustId = cc.CCCustId
		inner join Reward as r on r.RewCCNo = cc.CCNo

	-- if credit card number is provided and matches with database, select all rewards under that number
	else if exists (select * from CreditCard where CCNo = @ccno)
		select c.CustId, c.CustName, r.RewDesc, r.RewAmount, r.RewValidTill, r.RewStatus
		from CreditCard as cc 
		inner join Customer as c on c.CustId = cc.CCCustId
		inner join Reward as r on r.RewCCNo = cc.CCNo
		where cc.CCNo = @ccno

	-- if credit card number is provided but does not matches with database, return error
	else
		return -105 -- Credit card number provided does not match with database. Please try again.
end
go


/**====== Create View for Query 2 of PDF ======**/ 
if exists (select * from sys.objects where type = 'V' and name = 'Query2View') drop view Query2View
go

create or alter view Query2View as 

select top 1 CTMerchant, count(CTMerchant) as 'Count' from CardTransaction 
group by CTMerchant
order by count(CTMerchant) desc
go


/**====== Create View called CCCustomerView ======**/ 
if exists (select * from sys.objects where type = 'V' and name = 'CCCustomerView') drop view CCCustomerView
go

create or alter view CCCustomerView as 
select cc.CCNo, cc.CCCVV, cc.CCCreditLimit, cc.CCCurrentBal, cc.CCStatus, c.CustName
from CreditCard as cc inner join Customer as c on c.CustId = cc.CCCustId
go


----------------------------------------------------------------------------------------------------------------------------------

/**-----------------------------------------------**/
/**     Ambrish Krishna Muralitharan, S10223486G  **/
/**              Credit Card Statement            **/
/**                   Cashback                    **/
/**-----------------------------------------------**/

/**====== Create View for Query 4 of PDF ======**/ 
IF OBJECT_ID ('StatementView') IS NOT NULL DROP VIEW StatementView
GO

CREATE OR ALTER VIEW StatementView AS
	SELECT ct.CTCCNo, ccs.CCSNo, ccs.CCSDate, ccs.CCSPayDueDate, ccs.CCSCashback, ccs.CCSTotalAmountDue		-- Select all the variables needed to be displayed for the query
	FROM CreditCardStatement ccs																			-- State the primary table being used
	inner join CardTransaction ct on ccs.CCSNo = ct.CTCCSNo													-- Inner Join to pair 2 variables in 2 different tables together so that other variables can be used
	WHERE DATEPART(Year, ct.CTDate) = DATEPART(YEAR, ccs.CCSDate) 
	AND DATEPART(MONTH, ct.CTDate) = DATEPART(MONTH, ccs.CCSDate)											-- To ensure that the correct values for a specific date is being displayed
	GROUP BY ct.CTCCNo, ccs.CCSNo, ccs.CCSDate, ccs.CCSPayDueDate, ccs.CCSCashback, ccs.CCSTotalAmountDue	-- Group the Values by the Month and the Year specified in the input variable
go

/**====== Create procedure for cashback ======**/ 
IF OBJECT_ID ('uspCashback') IS NOT NULL DROP PROCEDURE uspCashback
GO

CREATE PROC uspCashback @OGAmount SMALLMONEY OUTPUT AS
BEGIN
	-- Calculate the cashback value using the formula Cashback = 1% of Amount
	SET @OGAmount = 0.01 * @OGAmount 
	RETURN @OGAmount 
END
GO

/**====== Create procedure for creating a new statement ======**/ 
IF OBJECT_ID ('uspCreateCreditCardStatement') IS NOT NULL DROP PROCEDURE uspCreateCreditCardStatement
GO

CREATE OR ALTER PROC uspCreateCreditCardStatement(@CCNo char(16), @CCSDate SMALLDATETIME) AS
BEGIN
	--DECLARE VARIABLES
	DECLARE @LastStNo CHAR(10), @NewStNo CHAR(10), @Amount SMALLMONEY, @DueDate SMALLDATETIME, @FinalAmount SMALLMONEY, @Cashback SMAllMONEY , @CheckAmount smallmoney

	-- CREATE NEW STATEMENT NUMBER
	SET @LastStNo = (SELECT TOP 1 CCSNo FROM CreditCardStatement ORDER BY CCSNo DESC )	-- FIND THE LAST STATEMENT NUMBER
	SET @NewStNo = SUBSTRING(@LastStNo, 2, 10) + 1										-- Splits 'S' from numeric portion and adds 1
	set @NewStNo = CONVERT(CHAR, @NewStNo)												-- Convert the new ending number to a character type
	SET @NewStNo = ('S' + '00000000' + @NewStNo)										-- Concatenate 'S' with new numeric portion

	-- CALCULATE AMOUNT SPENT FOR THE MONTH
	SET @Amount = (SELECT SUM(CTAmount) FROM CardTransaction 
					WHERE DATEPART(Year, CardTransaction.CTDate) = DATEPART(YEAR, @CCSDate) 
					AND DATEPART(MONTH, CardTransaction.CTDate) = DATEPART(MONTH, @CCSDate) 
					AND CTCCNo = @CCNo)

	-- Set the Payment Due Date as 3 weeks from the Statement Date
	SET @DueDate = DATEADD(WEEK, 3, @CCSDate) 

	-- Declare the conditions for the cashback: Minimum value for cashback to be activated is $800 and cahback is capped at $50
	set @Cashback = 0
	IF (@Amount > 800) 
	begin
		EXEC @Cashback = uspCashback @Amount
		if (@Cashback > 50)
			set @Cashback = 50
	end

	-- Set the final amount to be the difference between the original amount and the cashback value
	SET @FinalAmount = @Amount - @Cashback 

	-----------ERROR VALIDATION-------------
	-- Checks if credit card number length is less than 16
	IF (LEN(@CCNo) <> 16)
		RETURN -109 -- CARD LENGTH IS NOT 16 CHARACTERS, WORKS

	-- Checks if credit card exists
	IF NOT EXISTS (SELECT * FROM CreditCard cc where cc.CCNo = @CCNo)
		RETURN -110 -- CARD DOES NOT EXIST, WORKS

	-- Checks if credit card is active
	IF EXISTS (SELECT CCStatus FROM CreditCard WHERE CCStatus <> 'Active' and CCNo = @CCNo)
		RETURN -111 -- Credit Card is either expired, cancelled or suspended, WORKS

	-- Checks if statement has been created
	IF EXISTS (SELECT * FROM CreditCardStatement ccs inner join CardTransaction ct on ccs.CCSNo = ct.CTCCSNo
													inner join CreditCard cc on ct.CTCCNo = cc.CCNo
				where  ccs.CCSDate = @CCSDate and CCNo = @CCNo)
		RETURN -112 -- CARD STATEMENT HAS ALREADY BEEN CREATED, WORKS

	-- Checks if statement date is the end of the month
	IF (@CCSDate <> EOMONTH(@CCSDate))
		RETURN -113 -- Statement date provided is not the last day of the month, WORKS

	-- Checks for unknown error
	IF @@ERROR <> 0
		RETURN -104 -- UNEXPECTED ERROR OCCURS DURING INSERTION OF NEW RECORDS

	----INSERTION OF VALUES--------
	INSERT INTO CreditCardStatement(CCSNo, CCSDate, CCSPayDueDate, CCSCashback, CCSTotalAmountDue)
	VALUES (@NewStNo, @CCSDate, @DueDate, @Cashback, @FinalAmount)

	-- Check if Transaction amount exceeds the current balance for the month
	SET @CheckAmount = (SELECT CCCurrentBal FROM CreditCard cc where CCNo = @CCNo)

	IF @Amount > @CheckAmount
		UPDATE CardTransaction
		SET CTStatus = 'Failed'
		WHERE DATEPART(MONTH, CardTransaction.CTDate) = DATEPART(MONTH, @CCSDate) 

	ELSE
	begin
		-- Update the status of the Transaction once it has been added to the bill
		UPDATE CardTransaction
		SET CTStatus = 'Billed'
		WHERE DATEPART(MONTH, CardTransaction.CTDate) = DATEPART(MONTH, @CCSDate) 

		-- Update Credit Card Available Balance
		UPDATE CreditCard
		SET CCCurrentBal = CCCurrentBal - @Amount
		WHERE CCNo = @CCNo
	end

	-- Update the value of the CTCCSNo in the CardTransaction table after a new bill has been created
	UPDATE CardTransaction
	SET CTCCSNo = @NewStNo
	WHERE DATEPART(MONTH, CardTransaction.CTDate) = DATEPART(MONTH, @CCSDate) and CTCCNo = @CCNo
	
	-----Payment Processing
	UPDATE CreditCard
	SET CCCurrentBal = CCCreditLimit
	FROM CreditCard cc INNER JOIN CardTransaction ct ON cc.CCNo = ct.CTCCNo
	INNER JOIN CreditCardStatement ccs ON ct.CTCCSNo = ccs.CCSNo
	WHERE GETDATE() = ccs.CCSPayDueDate

	-- Call the view so that the user can see the transaction details for that specific month-----
	SELECT * FROM StatementView WHERE CTCCNo = @CCNo and CCSDate = @CCSDate

	RETURN
END
GO


/**====== Create trigger after insert on CreditCardStatement table ======**/ 
if exists (select * from sys.objects where type = 'TR' and name = 'trigStatement') drop trigger trigStatement
go

create or alter trigger trigStatement on CreditCardStatement after insert as
	print 'Credit Card Statement has successfully been created.'
	return
go

----------------------------------------------------------------------------------------------------------------------------------

/**-----------------------------------------------**/
/**            Tan Kok Kai, S10222863J            **/
/**                    Reward                    **/
/**-----------------------------------------------**/


/**====== Create procedure for creating a new reward ======**/ 
if exists (select * from sys.objects where type = 'P' and name = 'uspCreateReward') drop proc uspCreateReward
go

create or alter proc uspCreateReward(@Merchant varchar(100), @RewAmount smallmoney, @RewValidTill smalldatetime, @RewCCNo char(16)) as
begin
	-- Checks if credit card exists
	if not exists (select * from CreditCard c where c.CCNo = @RewCCNo)
		return -110 -- Credit card does not exist in the database

	-- Checks if merchant exists in database
	if not exists (select * from CardTransaction c where c.CTMerchant = @Merchant)
		return -106 -- Merchant does not exist in the database

	-- Checks if reward amount entered is valid
	if not (@RewAmount = 5 or @RewAmount = 10)
		return -116 -- Reward amount stated is not valid

	-- Checks if expiry date is set 6 months after creation date
	if (datediff(month, GETDATE(), @RewValidTill) != 6)
		return -115 -- Checks if expiry date is set 6 months after creation date

	-- Checks for unknown error
	if @@ERROR <> 0
		return -104

	insert into Reward (RewDesc, RewAmount, RewValidTill, RewRedeemDate, RewStatus, RewCCNo)
		values (@Merchant + ' Voucher', @RewAmount, @RewValidTill, Null, 'Available', @RewCCNo)
	return
end
go


/**====== Create procedure for counting the number of rewards given out by each merchant ======**/ 
if exists (select * from sys.objects where type = 'P' and name = 'uspCountRewardByMerchant') drop proc uspCountRewardByMerchant
go

create proc uspCountRewardByMerchant(@Merchant varchar(100) = 'All') as
begin
	-- If a merchant name is given, count all rewards under that merchant
	if exists (select * from reward r where r.RewDesc = @Merchant + ' Voucher')
		Select r.RewDesc as 'Reward', r.RewAmount as 'Amount', count(r.rewid) as 'Number of rewards' 
		from reward r 
		where r.RewDesc = @Merchant + ' Voucher'
		group by r.RewDesc, r.RewAmount

	-- If a merchant name is not given, count all rewards from all merchants
	else if (@Merchant = 'All')
		Select r.RewDesc as 'Reward', r.RewAmount as 'Amount', 
		count(r.rewid) as 'Number of rewards' from reward r 
		group by r.RewDesc, r.RewAmount 
		order by r.RewDesc, r.RewAmount

	-- If a merchant name is given but does not match with database, return error
	else 
		return -106 -- Merchant does not exist in the database
end
go


/**====== Create trigger after insert on Reward table after insert ======**/ 
if exists (select * from sys.objects where type = 'TR' and name = 'trigRewardInsert') drop trigger trigRewardInsert
go

create or alter TRIGGER trigRewardInsert ON Reward AFTER INSERT	AS
PRINT 'New reward has been inserted'
go


/**====== Create trigger after insert on Reward table after update ======**/ 
if exists (select * from sys.objects where type = 'TR' and name = 'trigRewardUpdate') drop trigger trigRewardUpdate
go

create or alter trigger trigRewardUpdate on Reward after update as
begin
	if Update(rewredeemdate)
		update reward set RewStatus = 'Claimed' where  RewID = (select i.RewID from inserted i)
		Print 'Rewards claimed successfully'
end
go


/**====== Create trigger after insert on Reward table instead of delete ======**/ 
if exists (select * from sys.objects where type = 'TR' and name = 'trigDeleteUpdate') drop trigger trigDeleteUpdate
go

create or alter trigger trigDeleteUpdate on Reward instead of delete as
begin
	print 'The reward status is updated to "Expired"'
	update Reward set RewStatus = 'Expired' where RewID = (select d.RewID from deleted d)
end
go


/**====== Create procedure to print error messages ======**/ 
if exists (select * from sys.objects where type = 'P' and name = 'uspErrorMsg') 
	drop proc uspErrorMsg
go

Create proc uspErrorMsg(@ErrorNo int) as
begin
	if @ErrorNo = 0
		print ''
	else if @ErrorNo = -101
		print 'Customer must be 21 years old and above to apply for a credit card'
	else if @ErrorNo = -102
		print 'Customer must be 70 years old and below to apply for a credit card'
	else if @ErrorNo = -103
		print 'Customer must have a minimal gross annual income of S$30k to apply for a credit card'
	else if @ErrorNo = -104
		print 'Unknown error occured. Please try again.'
	else if @ErrorNo = -105
		print 'Credit card number provided does not match with database. Please try again'
	else if @ErrorNo = -106
		print 'Merchant does not exist in database'
	else if @ErrorNo = -107
		print 'Transaction amount must be more than 0'
	else if @ErrorNo = -108
		print 'Transaction status does not exist'
	else if @ErrorNo = -109
		print 'Card number length must be 16'
	else if @ErrorNo = -110
		print 'Credit card does not exist in database'
	else if @ErrorNo = -111
		print 'Credit card status is not active'
	else if @ErrorNo = -112
		print 'Credit card statement already exist'
	else if @ErrorNo = -113
		print 'Statement date must be last day of the month'
	else if @ErrorNo = -114
		print 'Reward amount stated is not valid'
	else if @ErrorNo = -115
		print 'Reward expiry date must be 6 months from transaction'
	else if @ErrorNo = -116
		print 'Reward status is not available'
	return
end
go

/**====== Create procedure to check for expired rewards ======**/ 
if exists (select * from sys.objects where type = 'P' and name = 'uspExpiredRew') 
	drop proc uspExpiredRew
go

create proc uspExpiredRew (@CCno char(16))
as
	begin 
	if exists (select * from reward r where @CCno = r.RewCCNo and r.RewValidTill < GETDATE() and r.RewStatus = 'Available')
		delete reward where RewID = (select RewID from Reward r 
									where @CCno = r.RewCCNo and r.RewValidTill < GETDATE() and r.RewStatus = 'Available')
	end
go

/**====== Create procedure to check for available rewards ======**/ 
if exists (select * from sys.objects where type = 'P' and name = 'uspAvailableRew') 
	drop proc uspAvailableRew
go

create proc uspAvailableRew (@CCno char(16), @Merchant varchar(100), @deductAmount int output)
as
	begin 
	if exists (select * from reward r where @CCno = r.RewCCNo and @Merchant + ' Voucher' = r.RewDesc and
				r.RewStatus = 'Available')
		begin
		set @deductAmount = (select r.RewAmount from reward r where @CCno = r.RewCCNo and 
							@Merchant + ' Voucher' = r.RewDesc and r.RewStatus = 'Available')
		
		end
	else 
		set @deductAmount = 0
	return
	end

/**====== Create view for CreditCard and CardTransaction tables ======**/ 
if exists (select * from sys.objects where type = 'V' and name = 'TransactionMerchantView') drop view TransactionMerchantView
go

Create or alter view TransactionMerchantView as
	select ct.CTNo as 'Transaction ID',ct.CTMerchant as 'Merchant', ct.CTAmount as 'Amount', ct.CTDate as 'Date', cc.CCNo as 'Credit Card No', 
			cc.CCValidThru as 'Card Expiration date', c.CustName as 'Customer'
	from CardTransaction ct
	inner join CreditCard cc on ct.CTCCNo = cc.CCNo
	inner join Customer c on c.CustId = cc.CCCustId
	where ct.CTStatus = 'Billed'
go


/**====== Create view for Query 3 for PDF ======**/ 
if exists (select * from sys.objects where type = 'V' and name = 'Query3View') 	drop view Query3View
go

Create or alter view Query3View as
	select distinct(c.CustNRIC) as 'NRIC', c.CustName as 'Name',c.CustAddress as 'Address', 
	c.CustContact as 'Contact', c.CustEmail as 'Email', c.CustAnnualIncome as 'Annual Income', 
	c.CustStatus as 'Status', ccs.CCSTotalAmountDue as 'Total Amount Due'
	from customer c
	inner join CreditCard cc on cc.CCCustId = c.CustId
	inner join CardTransaction ct on cc.CCNo = ct.CTCCNo
	inner join CreditCardStatement ccs on ct.CTCCSNo = ccs.CCSNo
	where cc.CCCurrentBal < cc.CCCreditLimit and DATEDIFF(month, CCSPayDueDate, GETDATE()) = 1
go

----------------------------------------------------------------------------------------------------------------------------------

/**-------------------------------------------------**/
/** Hafeezur Rahman Bin Mohamed Ismail, S10227896K  **/
/**                   Transaction                   **/
/**-------------------------------------------------**/

use CreditCardSys 
go


/**====== Create procedure for transaction ======**/ 
if exists (select * from sys.objects where type='p' and name = 'uspCreateTransaction') drop proc uspCreateTransaction
GO


create or alter proc uspCreateTransaction (@TMerchant varchar(100), @TAmount smallmoney = 0, @TStatus varchar(10),
											@ccno char(16)) as
begin
	declare @RewAmount smallmoney, @lastTNO char(10), @newTNO varchar(10), @newDate smalldatetime, @deductAmount int

	-- Create new CTNo
	set @lastTNO = (select top 1 CTNo from CardTransaction order by CTNo desc)	-- Finds last id
	set @newTNO = SUBSTRING(@lastTNO, 2, 10) + 1									-- Splits 'C' from numeric portion and adds 1
	set @newTNO = ('T' + RIGHT('000000000' + CONVERT(VARCHAR(9), @newTNO), 9))	-- Concatenate 'C' with new numeric portion

	-- Merchant not found
	if not exists(select * from CardTransaction where CTMerchant = @TMerchant)
		return -106 -- Merchant not found

	-- Amount not found
	if @TAmount = 0
		return -107 -- Amount must be more than 0

	-- Status not found
	if not (@TStatus = 'Billed' or @TStatus = 'Failed' or @TStatus = 'Pending')
		return -108 --Status not found
	
	-- Set reward amount for reward before deduction
	if @TAmount >= 500.00 and @TAmount <= 999.99
		set @RewAmount = 5.00

	if @TAmount > 1000.00
		set @RewAmount = 10.00

	exec uspExpiredRew @ccno

	exec uspAvailableRew @ccno, @TMerchant, @deductAmount output
	
	set @TAmount = @TAmount - @deductAmount

	-- insert into card transaction
	insert into CardTransaction (CTNo, CTMerchant, CTAmount, CTDate, CTStatus, CTCCNo)
		values (@newTNO, @TMerchant, @TAmount, getdate(), @TStatus, @ccno)

	if @deductAmount > 0
		update reward set RewRedeemDate = getdate() where RewID = (select r.rewid from reward r where @CCno = r.RewCCNo and 
							@TMerchant + ' Voucher' = r.RewDesc and r.RewStatus = 'Available')

	-- checking for error
	if @@ERROR <> 0
		Return -104 -- Unknown error occured. Please try again.

	-- create new reward
	if @RewAmount is not null
	begin
		set @newDate = DATEADD(month, 6, getdate()) 
		exec uspCreateReward @TMerchant, @RewAmount, @newDate, @ccno
	end

	return
END
GO


/**====== Create trigger after insert on CardTransaction table ======**/ 
if exists(select * from sys.objects where type = 'TR' and name = 'trigTranAdded') drop trigger trigTranAdded
go

create or alter trigger trigTranAdded on CardTransaction after insert as
	print 'New Transaction Made'
	return
go


/**====== Create View for Query 1 of PDF ======**/ 
if exists (select * from sys.objects where type = 'V' and name = 'Query1View') 	drop view Query1View
go

Create or alter view Query1View as
	select c.CustId,c.CustName,c.CustNRIC, c.CustDOB from Customer c 
	inner join CreditCard cc on c.CustId = cc.CCCustId 
	inner join Reward r on cc.CCNo = r.RewCCNo
	where DATEDIFF(month, GETDATE(), r.RewValidTill) = 6
go
