/**-----------------------------------------------**/
/**       Lim Wee Liang Kelven, S10221788K        **/
/**             Credit Card Application           **/
/**-----------------------------------------------**/

use CreditCardSys

-- Test 1: under 21
declare @dob smalldatetime, @error int
set @dob = '1/1/2020'
exec @error = uspCreditCardApplication 123456789, test1, @dob, test1, 123, 456, 30000
exec uspErrorMsg @error
go

-- Test 2: over 70
declare @dob smalldatetime, @error int
set @dob = '1/1/1900'
exec @error = uspCreditCardApplication 123456789, test2, @dob, test2, 123, 456, 30000
exec uspErrorMsg @error
go

-- Test 3: under S$30k
declare @dob smalldatetime, @error int
set @dob = '1/1/1990'
exec @error = uspCreditCardApplication 123456789, test3, @dob, test3, 123, 456, 20000
exec uspErrorMsg @error
go

-- Test 4: everything okay
select * from CCCustomerView				-- See all customers with credit cards before insertion

declare @dob smalldatetime, @error int
set @dob = '1/1/1990'
exec @error = uspCreditCardApplication 123456789, 'sample1', @dob, 'address1', 123, 'sample1@mail.com', 30000
exec uspErrorMsg @error

set @dob = '1/1/1970'
exec @error = uspCreditCardApplication  121212121, 'sample2', @dob, 'address2', 456, 'sample2@mail.com', 50000
exec uspErrorMsg @error

select * from CCCustomerView				-- See all customers with credit cards after insertion
go

-- Test 5: uspCustomerReward proc: See all customers with rewards
-- No params
declare @error int
exec @error = uspCustomerReward
exec uspErrorMsg @error
go

-- Credit card number matches databse but no rewards
declare @error int
exec @error = uspCustomerReward 5181075091396053
exec uspErrorMsg @error
go

-- Credit card number matches with rewards
declare @error int
exec @error = uspCustomerReward 5443835770559378
exec uspErrorMsg @error
go

-- Credit card number does not match database
declare @error int
exec @error = uspCustomerReward 5
exec uspErrorMsg @error
go


----------------------------------------------------------------------------------------------------------------------------------

/**-------------------------------------------------**/
/** Hafeezur Rahman Bin Mohamed Ismail, S10227896K  **/
/**                   Transaction                   **/
/**-------------------------------------------------**/

-- IMPORTANT: CHANGE CREDIT CARD NUMBER EVERYTIME A NEW CREDIT CARD IS MADE

select * from CCCustomerView
select * from CreditCard
select * from CreditCardStatement


-- Test 1: Merchant not found
declare @error int
exec @error = uspCreateTransaction '', 600.00, 'Billed', 1125309809980655
exec uspErrorMsg @error
go

-- Test 2: Amount more than 0
declare @error int
exec @error = uspCreateTransaction 'ADB Jewelry', 0, 'Billed', 1125309809980655
exec uspErrorMsg @error
go

-- Test 3: Status not found
declare @error int
exec @error = uspCreateTransaction 'ADB Jewelry', 600.00, '', 1125309809980655
exec uspErrorMsg @error
go

-- Test 4: Everything OK, test for creating reward
select * from CardTransaction
select * from Reward

declare @error int
exec @error = uspCreateTransaction 'ADB Jewelry', 600.00, 'Pending', 1125309809980655
exec uspErrorMsg @error

exec @error = uspCreateTransaction 'ADB Travel', 1100.00, 'Pending', 6519866814662487
exec uspErrorMsg @error

exec @error = uspCreateTransaction 'ADB Travel', 500.00, 'Pending', 6519866814662487
exec uspErrorMsg @error

exec @error = uspCreateTransaction 'ADB Grocery', 50.00, 'Pending', 6519866814662487
exec uspErrorMsg @error
go

select * from CardTransaction
select * from Reward
select * from CreditCard

----------------------------------------------------------------------------------------------------------------------------------

/**-----------------------------------------------**/
/**     Ambrish Krishna Muralitharan, S10223486G  **/
/**              Credit Card Statement            **/
/**                   Cashback                    **/
/**-----------------------------------------------**/


--SCENARIO 1: Card Length is not 16 Characters
declare @status int
exec @status = uspCreateCreditCardStatement 5, '2022-12-31'
exec uspErrorMsg @status
go

--SCENARIO 2: Card does not exist
declare @status int
exec @status = uspCreateCreditCardStatement 5555555555555555, '2022-11-30'
exec uspErrorMsg @status
go

--SCENARIO 3: Credit Card is either expired, cancelled or suspended
declare @status int
exec @status = uspCreateCreditCardStatement 5395164704886973, '2022-11-30'
exec uspErrorMsg @status
go

--SCENARIO 4: Card statement has already been created
declare @status int
exec @status = uspCreateCreditCardStatement 5443835770559378, '2022-09-30'
exec uspErrorMsg @status
go

--SCENARIO 5: Statement date provided is not the last day of the month
declare @status int
exec @status = uspCreateCreditCardStatement 5443835770559378, '2022-11-05'
exec uspErrorMsg @status
go

--SCENARIO 6: Everything works fine
select * from CardTransaction
select * from CreditCardStatement

declare @status int
exec @status = uspCreateCreditCardStatement 1125309809980655, '2022-12-31'
exec uspErrorMsg @status

exec @status = uspCreateCreditCardStatement 6519866814662487, '2022-12-31'
exec uspErrorMsg @status
go

select * from CardTransaction
select * from CreditCardStatement

----------------------------------------------------------------------------------------------------------------------------------

/**-----------------------------------------------**/
/**            Tan Kok Kai, S10222863J            **/
/**                     Reward                    **/
/**-----------------------------------------------**/

select * from reward
select * from CreditCard
select * from customer
select * from CardTransaction

-- Validation for creating reward
-- Credit card number does not match database
declare @status int
exec @status = uspCreateReward 'ADB Petrol', 5, '2022-12-12', '1022212222222222'
exec uspErrorMsg @status
go

-- Merchant name does not match database
declare @status int
exec @status = uspCreateReward 'ADB Petrols', 5, '2022-12-12', '5443835770559378'
exec uspErrorMsg @status
go

-- Reward amount is not 5 or 10
declare @status int
exec @status = uspCreateReward 'ADB Petrol', 7, '2022-12-12', '5443835770559378'
exec uspErrorMsg @status
go

-- Checks if expiry date is set 6 months after creation date
declare @status int
exec @status = uspCreateReward 'ADB Petrol', 5, '2022-12-12', '5443835770559378'
exec uspErrorMsg @status
go

-- Everything OK
select * from CardTransaction
select * from Reward
declare @status int
exec @status = uspCreateReward 'ADB Jewelry', 5, '2023-6-03', 6892680313180818
exec uspErrorMsg @status
select * from Reward
go

-- Test triggers
select * from reward
update reward set RewDesc = 'ADB Jewelry Voucher' where  RewID = 5
update reward set RewRedeemDate = getdate() where  RewID = 5
delete reward where rewid = 3

-- Test Views
select * from TransactionMerchantView

-- Test Procedure
exec uspCountRewardByMerchant
exec uspCountRewardByMerchant 'ADB Jewelry'
exec uspCountRewardByMerchant 'ADB Jewelry Voucher'


----------------------------------------------------------------------------------------------------------------------------------

/**-----------------------------------------------**/
/**                  Show Queries                 **/
/**-----------------------------------------------**/

-- Query 1: Details of customers who have earned rewards in the current month
select * from Query1View

-- Query 2: Name of merchant with the most number of transactions
select * from Query2View

-- Query 3: Details of customers who have not paid their bills last month
--select * from Customer
--select * from CreditCard
--select * from CardTransaction
select * from Query3View

-- Query 4 : Details of transactions for a given customer for a given month
select * from StatementView
